package com.example.mvvmwithhiltcounterapps.repository

import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class CounterRepository @Inject constructor() {
    private var counter = 0

    fun increment(): Int {
        return ++counter
    }

    fun decrement(): Int {
        return --counter
    }

    fun getCurrentValue(): Int {
        return counter
    }
} 